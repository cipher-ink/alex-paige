---
cssclasses:
  - novel-formatting
---
The opening ceremony was *long*.

We walked down the staircase which curved to the left to join with the other on the opposite side, creating a wider central set of stairs leading into one of the largest rooms I’d ever seen. Mr. Terrell had called it the ‘Grand Central Station’ of Caldwell Hall, but that was putting it lightly.

The central room was impossibly big–enchanted I assumed–reaching five stories tall with each story taking up at least twenty feet. Thick white marble columns supported each floor, adorned with lit scones and large banners with the same griffin as my uniform.

Other than the banners, it was difficult to make out anything on the other floors because of the incoherent set of staircases and walkways that filled the upper section of the hall. Each floor looked to have a connection with each other floor, but the way they were made twisted and turned into a maze. Some went up and down, some twisted, one looked to turn upside down halfway through, and one was just a ladder bolted into the side of the marble. There was no discernible pattern to them, as if they were created at the convenience and whim of the person who needed it rather than being implemented when the building was made.

Ahead of me was the large opening that lead to the “cathedral”, but we’ll get there in a minute. To the right of it, heading off at a diagonal was a thin hallway ending in a staircase leading even further down beyond sight. Directly to the right, another hall lead further down with doorways on the left side before abruptly ending and turning left to the rest of the building.

The left was the most open; the first floor looked like an exhibit area with dioramas littered throughout showing all sorts of things, the coolest of which was this giant pterodactyl like creature that walked on four legs like a panther. I didn’t get a closer look before Mr. Terrell pulled me along, but he said it was called a Sedrek.

The actual cathedral was just as promised: an impossibly tall room with a vaulted ceiling and stained glass windows lining either wall like towering storybooks I couldn’t understand. Each panel was enormous–at least thirty feet tall–and they didn’t depict anything as simple as saints or symbols. They were giant collages, dense with motion: armored and robed figures clashing against creatures with too many limbs, great winged silhouettes, and circles upon circles of interlocking symbols all around the edges that shifted when I looked at them too long. In one, a creature that looked like a lion made of shadow towered over a crumbling city. In another, a figure in a tall hat stood with arms raised while the glass around him fractured into a web of jagged colors, as if the window itself had been struck by something immense.

Even from here I could feel the hum of magic emanating behind each window, keeping them lit from the back. Mr. Terrell had told me I’d be able to sense magic from a distance, but it felt more like when the hairs on the back of your neck stand up than a pinpoint direction.

Pews lined the entire floor leading to the back where a large statue of a wizard stood. So far I’d yet to experience anything stereotypical of what I thought was “fantasy”, but this wizard was exactly what you would have expected. Long flowing robes, giant brimmed cap, staff in one hand, and book in the other. The hat even looked eerily familiar to that figure in the glass.

“Who’s that?” I asked, pointing to the statue.

“William Holden,” Mr. Terrell responded, “He’s one of the original founders of the Sanctum. And a hero who sacrificed himself to create the Veil.”

As much as I wanted to ask for more information, a loud ringing from a bell interrupted my train of thought, sending my eyes down from the statue and onto the podium and rows of seats facing towards us, which were now filled up with faculty looking out over the sea of students.

Mr. Terrell shuffled me into one of the pews towards the middle of the room. The bench was already crowded–not just with kids my age, but with a whole spectrum of faces I hadn’t been expecting. A boy who couldn’t have been older than eleven sat two rows ahead, swinging his legs because they didn’t even reach the marble floors. next to him, a girl was crying silently into a stuffed rabbit until her parents next to her gently pried it from her hands. It was only then I realized that it was, in fact, not stuffed. Further back, I spotted a man with a beard and weathered uniform that had seen some actual use, sitting rigid with his hands on his knees like he was waiting for a deployment briefing rather than orientation. There were some others like me, however. Scattered throughout the pews like we were all trying not to cluster together. I counted maybe fifteen, twenty of us in total.

I looked to my side, seeing a Najiir next to me, her ears just poking out the top of the mini beret she was wearing. Unlike the boy I had seen in the museum, her appearance was much closer to mine than it was a cat. She wasn’t covered in fur, instead having tufts of it on the sides of her head. Her eyes were the same though–a cat-like slit–and she had whiskers growing out just under her nose where her dimples would be. I must have been staring, because she turned to me and smiled. I averted my gaze quickly, blushing out of embarrassment, before awkwardly trying to save the situation.

“I, uh…I like your hat.”

“Thanks!” she said with a bright smile. Her ears did a little flick and a tail suddenly appeared between us, waving back and forth enough to slightly hit my side. I must have had a surprised look on my face, cause she quickly apologized and grabbed her tail. She un-tucked her shirt and I watched as her tail suddenly disappear under it, wrapping around her waist as she tucked it back in. I didn’t have anything to say in response, but I tried.

“Oh, no, it’s fine. Really. I’m Alex.”

“Maria,” she responded, her ears drooping a little and red blush filling her cheeks with the same embarrassment that I’d had seconds earlier. Just as I was about to try and break the ice with some dumb joke, the lights in the room flickered out and silence fell across the room.

It must have only been seconds, but it felt like the silence loomed over the room forever, waiting for something to break it, until finally the lights behind the stained glass came back on, illuminating the entire room in a rainbow of color. 

A single spot of white cut through the color and locked onto the podium beneath the statue. A man stood there–no, he had simple appeared; apparated into the space. He was tall and lean, wearing a dark pinstripe suit that looked almost normal if not for the half-cape over his right shoulder. Even from my seat all the way in the back I could feel something not quite right with the fabric; little points of light drifted across it like slow-moving stars. He had a neat mustache and a long thin goatee, carrying himself with a stillness that made the entire room seem loud by comparison. He raised both hands in a single, showy, motion with his palms up. The crest on his left arm lit with a cool, watery green.

And then the windows moved.

The colors didn’t just glow anymore; they peeled. The armored figures lifted free of the glass, unspooling into ribbons of light that hung in the air. Then the creatures–the limbed things, the winged silhouettes, the lion–pulled themselves out of their panels and drifted above us, massive and translucent, turning the cathedral into a three-dimensional painting. The magic circles spun loose from the edges, rotating slowly and casting lattice-like shadows across our upturned faces. It was a light show, yeah, but it as heavier. Ancient. The hum of magic i’d heard earlier had now turned into a symphony.

“Woah.” I heard Maria gasp beside me, and I couldn’t even manage that much. I simply watched as the figures began to animate in sequence. Silent battles replayed in flashes overhead. The wizard in the tall hat raised his arms again and again, the glass around him shattering and reforming in a loop. The lion reared, it’s jaws opening wide enough to swallow the city whole.

It took all the effort I had to pull myself away from the dazzling light show, but I felt an odd sensation in my gut. I looked down, back to the man at the podium. I may have been all the way in the back, but even I could feel his cool gaze as he scanned the room, everyone else too distracted to notice. Maria’s tail had untucked itself and was swishing back and forth, bapping me on the leg over and over.

His gaze fell on me, or at least that’s what it felt like. He smiled and slowly lowered his arms, the light in his crest slowly fading. The floating scenery above my head whisked away as the lights from the windows dimmed and both the soft yellow light and roaring applause began to fill the room. All the while, that man was still looking at me. I wanted to look away, but something kept me rooted, refusing to yield.

As his gaze eventually left mine, the applause softened into the same stillness from before the lightshow. It had settled so completely that I could hear the creak of the pew beneath me and the faint rustle of Maria’s shirt as she once again tucked in her tail.

“Students, family, and faculty…” his voice was soft, but it found every corner of the vaulted room without any need for force. “I welcome you to the Sanctum, and to the class of six seventy one.”

A polite ripple of applause moved through the front pews. I clapped twice before noticing that no one behind them was clapping, hands flat in their laps, and so I dropped mine with heat rising in my cheeks.

“You sit beneath the history of this institution,” he continued, folding his hands on the podium. His cape shifted; stars crawling along the fabric. “These windows that have watched every class come and go. Every founder. Every headmaster. Every sacrifice made so that this institution may endure. They do not distinguish between First Ring or Third. They do not recognize houses, banners, or family names. Thy only ask that you look. And that you listen.”

I felt Maria sit up straighter beside me, her ears fully perked. The boy who’d been swinging his legs had now gone completely still, gazing up with an earnestness that made something twist in my cold hard chest.

There was a student in the third row ahead of me–his uniform somehow even more pristine than mine–looking unimpressed with his arms crossed. Another next to him yawned with no attempt to hide it.

“I am professor Vael, your one hundred and twenty first headmaster, and I see great things ahead for you.”

He took a step–just one measured step left–and the spotlight followed him like it had been waiting in anticipated breath.

“The chains around your necks–” he gestured into the crowd, and I found my fingers moving the three chains that held my mantle, “–do not symbolize status. Nor rank. They are questions. And you will spend your years here attempting to answer them. Some of you will find your answers quickly. Some will struggle.”

His gaze slowly adjusted down to meet mine again, and I felt a cool chill run down my spine.

“Some will not make it at all.”

The faculty in the front row sat rigid, almost reverent as the man once again looked away, taking a couple steps in the opposite direcetion.

“The Sanctum does not promise to make you great,” he continued. “We promise only to make you ready. Ready to prove, to both yourself, and the rest of the world, that you are worthy to carry forward the weight that you now feel resting on your shoulders.”

With those words, the silence had gone beyond quiet into something weighty. I felt the mantle on my shoulders get a bit heavier, and even the youngest students seemed to feel it.

“Study hard,” he said, a grin smearing across his face. “Be wild. Be kind. Be clever. And try not to set anything ablaze before October.”

A surprised laught escaped from a few of the crowd, me incuded, but they were quickly smothered. The headmaster’s expression didn’t change, but something in the set of his shoulders shifted, almost relaxed now.

“Welcome to the Sanctum,” he finished. “You’re dismissed.”
