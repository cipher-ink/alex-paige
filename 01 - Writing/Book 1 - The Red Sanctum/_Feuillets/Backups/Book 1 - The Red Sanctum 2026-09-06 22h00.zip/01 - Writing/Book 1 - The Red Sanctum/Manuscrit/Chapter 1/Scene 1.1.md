---
title:
order: 1
synopsis:
status:
label:
goal: undefined
tags:
date:
notes:
compile: true
---
Look: I didn’t wake up this morning thinking *“You know what sounds fun? Blowing a chunk out of the Museum of Natural History!”*, but here we are. Chaos and I are kind of on a first-name basis.


Magic isn’t supposed to be real. It’s the kind of thing you see in books and at the movies. Heroes, princesses, wizards, all of that. But life’s full of curve balls, and this is yours: Magic? Totally real. And it’s always arm in arm with trouble.


Have you ever seen something in the corner of your eye that just *wasn’t right*? Like the world tilted for a second and you glimpsed the impossible? Or maybe you got tangled up in something unexplainable and weird. Those times? Real. One hundred percent. And they weren’t accidents either.


You have magic. That’s the only way you’re reading this book. But even if you aren’t aware of it, that doesn’t mean it’s too late. So here’s your last chance.
If you want to live your life in blissful ignorance, here’s your cue to exit. Seriously. This is the red light. Hit the brakes, close this book, toss it in the trash, or burn it.    
Whatever you do is up to you.


But…if you want answers. If you’re willing to face the consequences and tear down the curtain to see the wizard behind it, then keep reading.
But buckle up, because this ride doesn’t come with seat belts.

