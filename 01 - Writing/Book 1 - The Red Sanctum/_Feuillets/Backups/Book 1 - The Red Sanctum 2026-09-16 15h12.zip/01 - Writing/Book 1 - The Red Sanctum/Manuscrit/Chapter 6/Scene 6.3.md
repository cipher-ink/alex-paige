---
title: 
short_title: 
order: 3
synopsis: 
status: 
label: 
goal: undefined
tags: 
date: 
notes: 
compile: true
---

“Hey.”

…

“So, um…yeah. I’m sorry it took me this long to visit.”

…

“I don’t even know what to say.”

…

“Mr. Terrell has been taking care of me. Well…he’s trying. I’m not making it easy.”

…

“He brings me food. He’s a good guy—really nice, even though I’ve been ignoring him. But you probably knew he was nice already. You always know.”

…

“I’ve been reading. *A lot, actually*. These books are wild. Magic is real, Dad. I know you knew that already, but like—dragons, griffins, wizards, all real. It’s crazy. Oh, they’re called ‘Operators’ instead of wizards now, apparently. Get this, they have social media sites for magic. RoxApp, I think it’s called. I thought RoxCorp was a pharmacy company or something, but I guess…oh, sorry. I was rambling.”

…

“I don’t—I’m not mad anymore. I was at first. Finding out that you and Mom hid all this from me. It wasn’t fun, but I get it now. You were trying to keep me safe. From what, exactly…I’m still trying to figure out. But I know you had your reasons.”

…

“I know that, but…”

…

“I go to the school in the fall. Mr. Terrell’s supposed to help me catch up over the summer…if I let him. Apparently, I’ll be a fifth year. Whatever that means. I doubt it will be a ‘look at the cool new transfer student’ and more like ‘who’s this random girl who doesn’t even know about *dingledorfs’* or whatever weird magic terms they throw at me.”

…

“I know, I know. I need to talk to Mr. Terrell. It’s just—it’s been hard. I don’t need to tell you that.”

…

…

“I-I want a hug, Dad.”

…

…

“I met someone. A twig girl named Jen. She’s…weird, but in a good way. I’m not sure if you knew her, but she knew Mom. Oh, and get this, apparently Mom saved her from a dragon. No big deal, though. I could have done that, haha.”

…

“She showed me some flowers that Mom had planted. They were…special. Jen said that I have the same magic as Mom, and for once, I felt some sort of connection. Like I had a piece of her left. You always talked about her like she was this unreachable star, and I—I never felt like I could shine that brightly.”

…

“I had a dream about Mom, too. Sorry I never told you. She saw me, Dad. Like, she actually *saw* me. Maybe it means something. Or maybe it’s just wishful thinking.”

…

“Jen thinks Mom is alive. You’d probably agree. You both hold onto this…this hope. I let go of that a long time ago. It was easier than holding on. But…”

…

“Now I remember her. Barely, but enough. She—she used to hum this song to me before bed.”

>*In a land where dreams take flight,*

>*Lived a girl with eyes so bright,*

>*Like shining stars,*

>*They shone so far,*

>*As she climbed a hill one night.*

>*The tallest hill in all the land,*

>*Atop she stood reaching out with her hand,*

>*She’d reach for a star,*

>*And fall back so far,*

>*Back down the hill she would land.*

>*Reach, reach for the stars above,*

>*For a dream is made of what you love,*

>*You may fall,*

>*You may bruise,*

>*You may hope,*

>*You may lose,*

>*You’ll give up and stop reaching for stars,*

>*Atop that hill so tall and so large,*

>*But remember your dream,*

>*As you reach up above,*

>*A dream that’s made from all of your love.*

“…sorry. I didn’t mean to start crying. I’ve done that so much lately, I thought I was out of tears.”

…

“I believe you. Or at least, I choose to. Maybe she’s still out there, somewhere. I don’t know how, but…I’ll find her. I have to.”

…

*She’s all I have left.*

…

“Thats my promise, okay Dad? The Paige family doesn’t break their promises.”

…

…

“I hope you’re okay. Wherever you are.”

…

“I love you.”
